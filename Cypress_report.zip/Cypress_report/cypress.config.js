const { defineConfig } = require('cypress');

module.exports = defineConfig({
  reporter: 'mochawesome',
  reporterOptions: {
    reportDir: 'cypress/reports/mocha',
    overwrite: false,
    html: true,
    json: true
  },
  e2e: {
    // Your Cypress configuration for tests
    setupNodeEvents(on, config) {
      return config;
    }
  }
});
