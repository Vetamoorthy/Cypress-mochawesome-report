 //Lumati Onboard welcome
 describe('Lumati Onboard-Welcome', () => {
  beforeEach(() => {
    cy.viewport(1920,1080); // Adjust dimensions as needed
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').should('not.exist');
  });
  it('Must display Welcome page', () => {
        // Wait for 10 seconds for the element to appear
        // cy.get('#import-document').wait(10000);
        // cy.viewport(1920,1080)
    cy.visit('https://app.lumati.com/onboard-welcome');
    
    // Click on the first element with class 'ion-margin-top'
    cy.get('.ion-margin-top').click();
    cy.wait(1000);

    // Click on the element with ID 'terms'
    cy.get('#terms').click();
    cy.wait(1000);

    // Click on the button within the footer
    cy.contains('Next').click();
    cy.wait(1000);
  });
});

 //Sign in page
describe('lumati Sign-In page', () => {
  beforeEach(() => {
    cy.viewport(1920,1080); // Adjust dimensions as needed
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').should('not.exist');

  });
  it('Should have SignIn pge', () => {
    // cy.viewport(1920,1080)
    cy.visit('https://app.lumati.com/login')
    cy.wait(1000)
   //Sign In 
   cy.get(':nth-child(2) > ion-col.ios > .ion-color > .button-inner').click();
    cy.wait(30000);
  })
})

 
 //Settings

describe('Settings', ()=> {
  beforeEach(() => {
    cy.viewport(1920,1080); // Adjust dimensions as needed
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').should('not.exist');

  });
  it('Account',()=>{
    // cy.viewport(1920,1080)
    cy.visit('https://app.lumati.com/tabs/stack')
    cy.wait(20000)
    //Settings
    cy.get('app-user-profile.sc-ion-buttons-ios > .ios > .material-symbols-outlined').click({force:true});
    cy.wait(1000)
    //Account
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(1) > .item-has-start-slot').click({force:true});
    cy.wait(1000)
    //Edit
    // cy.get('.buttons-last-slot > .ng-star-inserted').click({force:true});
    cy.contains('Edit').click({force:true})
    cy.wait(1000)

    //First name
    cy.get('#ion-input-0').clear().type('Vetamoorthy');
    cy.wait(1000)
    //Last name
    cy.get('#ion-input-1').clear().type('RG');
    cy.wait(1000)
    //DOB  
    cy.get('#userDatetime > .ios').click({force:true});
    cy.wait(1000)
    //Done
    cy.get('.no-padding-top > .buttons-last-slot > .sc-ion-buttons-ios').click({force:true});
    cy.wait(1000)
    //Pronoun
    cy.get('#userPronouns > .ios').click({force:true});
    cy.wait(1000)

    cy.get('.action-sheet-container > :nth-child(1) > :nth-child(3)').click({force:true});
    cy.wait(1000)
    //Save
    // cy.get('.buttons-last-slot > .ng-star-inserted').click({force:true});
    cy.contains('Save').click({force:true})
    cy.wait(1000)

    //Back
    // cy.get('.buttons-first-slot > .ng-star-inserted').click({force:true});
    // cy.contains('Profile').click({force:true});
    cy.get('.toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    cy.wait(1000)
    
    // //Daily Schedule
    // cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').click({force:true});
    // cy.wait(1000)
    // //Save
    // cy.get('.can-go-back > .header-translucent > .toolbar-title-default > .buttons-last-slot > .sc-ion-buttons-ios').click({force:true})
    // cy.wait(1000)
    //Subscriptions& Recharge
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(3) > .item-has-start-slot > .sc-ion-label-ios-h').click({force:true})
    cy.wait(1000)
    //Profile Back
    cy.get('.can-go-back > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    cy.wait(1000)
  //Language and Region
  cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(4) > .item-has-start-slot > .sc-ion-label-ios-h').click({force:true})
    cy.wait(1000)
   //Region
   cy.get('#select-region > ion-text.ios').click({force:true})
    cy.wait(1000)
    //Country
    cy.get('#modal-list > :nth-child(2)').click({force:true})
    cy.wait(1000)
  //  //Language
  //  cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(4) > .item-has-start-slot').click({force:true})
  //   cy.wait(1000)
  //   cy.get(':nth-child(1) > .in-item > .sc-ion-label-ios-h > h2.sc-ion-label-ios').click({force:true})
  //   cy.wait(1000)
  //   //Back
  //   cy.get('app-user-settings.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
  //   cy.wait(1000)
    //Date
    // cy.get('.ng-star-inserted > :nth-child(7)').click({force:true})
    // cy.wait(1000)
    // //Date Select
    // cy.get('ion-radio-group.ng-star-inserted > :nth-child(1) > .ios').click({force:true})
    // cy.wait(1000)
    // //Back
    // cy.get('app-user-settings.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    // cy.wait(1000)
    //Profile- Back
    cy.get('.can-go-back > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    cy.wait(1000)

    // //Appearence
    // cy.get(':nth-child(5) > .item-has-start-slot > .sc-ion-label-ios-h').click({force:true})
    // cy.wait(1000)
    // //Light
    // cy.get('ion-radio-group.ios > :nth-child(2) > .ios').click({force:true})
    // cy.wait(1000)
    // //Back
    // cy.get('.toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    // cy.wait(1000)

    //Feedback
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(5) > .item-has-start-slot > .sc-ion-label-ios-h').click({force:true})
    cy.wait(1000)
    //Bug or Issue
    cy.get(':nth-child(2) > .in-item > .sc-ion-label-ios-h > h2.sc-ion-label-ios').click({force:true})
    cy.wait(1000)
    //Next
    cy.get('ion-toolbar.ios > .ion-color').click({force:true})
    cy.wait(1000)
    //Description Box
    cy.get('#ion-textarea-0').type('Lumati testing is under process')
    cy.wait(1000)
    //Send
    cy.get('app-send-feedback.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
    cy.wait(5000)


    // //Settings
    // cy.get('.buttons-last-slot').click({force:true});
    // cy.wait(1000)
    
    // //About
    // cy.get(':nth-child(7) > .item-has-start-slot > .sc-ion-label-ios-h').click({force:true});
    // cy.wait(1000)
    // //Open Sources
    // cy.get('.can-go-back > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').click({force:true});
    // cy.wait(1000)
    // //Capacitor Android
    // cy.get('.list-ios > :nth-child(10)').click({force:true});
    // cy.wait(1000)
    // //Back
    // cy.get('app-open-source-license.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true});
    // cy.wait(1000)
    // //About
    // cy.get('app-open-source-projects.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true});
    // cy.wait(1000)
    // //Privacy
    // cy.get('.can-go-back > .content-ltr > :nth-child(4) > :nth-child(1) > .sc-ion-label-ios-h').click({force:true});
    // cy.wait(1000)
    // //About-Back
    // cy.get('app-privacy.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    // cy.wait(1000)
    // // Terms and Conditions
    // cy.get('.content-ltr > :nth-child(4) > :nth-child(2)').click({force:true});
    // cy.wait(1000)
    // //About back
    // cy.get('app-terms-and-condition.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    // cy.wait(1000)
    // //Profile- back
    // cy.get('.can-go-back > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click();
    // cy.wait(1000)
    // //Done
    // cy.get('ion-nav > .ion-page > .header-ios > .toolbar-title-default > .buttons-last-slot > .sc-ion-buttons-ios').click();
    // cy.wait(1000)
  })
 }) 

  //Stack
describe('Stack',()=>{
  beforeEach(() => {
    cy.viewport(1920,1080); // Adjust dimensions as needed
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').should('not.exist');

  });
    it('About Stack',()=>{
      // cy.viewport(1920,1080)
      cy.visit('https://app.lumati.com/tabs/stack')
      cy.wait(30000)
      //Manage stack
      // cy.get('sc-ion-label-ios-h sc-ion-label-ios-s ion-color ion-color-primary ios in-item-color').click({force:true})
      // cy.get(':nth-child(119) > .ion-color-light').should('be.visible').click({force:true})
      cy.contains('ion-label', 'Manage Stack').click({force:true});
    
      cy.wait(1000);
  
      //Add Supplement
      cy.contains('Add Supplement').click({force:true});
      cy.wait(1000);
  
      //Skip
      cy.contains('Skip').click();
      cy.wait(1000);
  
      //Product Info
      cy.get(':nth-child(1) > .ion-color > .custom-input > .input-wrapper > .native-wrapper').clear().type('Ambrosia');
      
      cy.get(':nth-child(2) > .ion-color > .custom-input > .input-wrapper > .native-wrapper').clear().type('Pedigree');
      
      cy.get('.can-go-back > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      cy.wait(1000);
      //Capsule
      cy.get(':nth-child(3) > .ng-untouched > :nth-child(1) > .in-item').click({force:true})
      
      cy.wait(1000);
  
      //Next
  
      cy.get('app-product-type.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      cy.wait(1000);
  
  
      //Product quantity
  
      cy.get(':nth-child(2) > .ion-color > .ion-text-end > .input-wrapper > .native-wrapper').clear().type('10000');
  
      cy.get(':nth-child(4) > .ion-color > .ion-text-end > .input-wrapper > .native-wrapper').clear().type('100');
      cy.wait(1000);
  
  
      //Next
      cy.get('app-product-quantity.ion-page > .footer-ios > ion-toolbar.ios > .button-round').click({force:true})
      cy.wait(1000);

  
      cy.get('app-schedule-product.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      cy.wait(1000);
  
      //As Needed
      cy.get(':nth-child(3) > ion-segment.ios > .segment-button-after-checked').click({force:true})
      cy.wait(1000);

      //Next
      cy.get('app-schedule-product.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      cy.wait(1000);


      //Done
      cy.get('app-review-product-details.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      cy.wait(1000);
  
  
      //Deleting Ambrosia
      cy.get('.can-go-back > .content-ltr > :nth-child(1) > .med-item').click({force:true});
      cy.wait(1000);
  
      //Delete Product
      cy.contains('Delete Product').click();
      cy.wait(1000);
  
      //Delete
      cy.get('.alert-button-role-confirm').click({force:true})
      cy.wait(1000);

      // //Add Supplement
      // cy.contains('Add Supplement').click({force:true});
      // cy.wait(1000);
     
      // //Amvacol 80 tablets
      // cy.get(':nth-child(5) > .ion-text-nowrap > h2.sc-ion-label-ios').click({force:true})
      // cy.wait(1000);

      // //Product Info
      // cy.get('#ion-input-6').clear().type('Zeo Charge');  
      // cy.wait(1000);

      // cy.get('#ion-input-7').clear().type('Zeo');
      // cy.wait(1000);

      // //Next
      // cy.get('.can-go-back > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      // cy.wait(1000);

      // //Powder
      // cy.get(':nth-child(3) > .ng-untouched > :nth-child(2) > .in-item').click({force:true});
      // cy.wait(2000);

      // //Next
      // cy.get('[style="z-index: 101;"] > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      // cy.wait(1000);
   
      // //Product Quantity
      // cy.get(':nth-child(2) > .ion-color > .ion-text-end > .input-wrapper > .native-wrapper').clear().type('200');
      // cy.wait(1000);

      // cy.get(':nth-child(4) > .ion-color > .ion-text-end > .input-wrapper > .native-wrapper').clear().type('2');
      // cy.wait(3000);

      // //Next
      // cy.get('app-product-quantity.ion-page > .footer-ios > ion-toolbar.ios > .button-round').click({force:true})
      // cy.wait(1000);

      // //Next
      // cy.get('app-schedule-product.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      // cy.wait(1000);

      // //Done
      // cy.get('app-review-product-details.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      // cy.wait(1000);


      // //Deleting product
      // cy.get('.can-go-back > .content-ltr > :nth-child(1) > .med-item').click({force:true});
      // cy.wait(1000);
  
      // //Delete Product
      // cy.contains('Delete Product').click();
      // cy.wait(1000);
  
      // //Delete
      // cy.get('.alert-button-role-confirm').click({force:true})
      // cy.wait(1000);


      //  //Add Supplement
      //  cy.contains('Add Supplement').click({force:true});
      //  cy.wait(1000);
      
      //  //Brain Smarts
      //  cy.get(':nth-child(11) > .ion-text-nowrap > h2.sc-ion-label-ios').click({force:true})
      //  cy.wait(1000);
 
      //  //Product Info
      //  cy.get('#ion-input-12').clear().type('Zeo Charge');  
      //  cy.wait(1000);
 
      //  cy.get('#ion-input-13').clear().type('Zeo');
      //  cy.wait(1000);
 
      //  //Next
      //  cy.get('.can-go-back > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      //  cy.wait(1000);
 
      //  //Powder
      //  cy.get(':nth-child(3) > .ng-untouched > :nth-child(2) > .in-item').click({force:true});
      //  cy.wait(2000);
 
      //  //Next
      //  cy.get('[style="z-index: 101;"] > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      //  cy.wait(1000);
    
      //  //Product Quantity
      //  cy.get(':nth-child(2) > .ion-color > .ion-text-end > .input-wrapper > .native-wrapper').clear().type('200');
      //  cy.wait(1000);
 
      //  cy.get(':nth-child(4) > .ion-color > .ion-text-end > .input-wrapper > .native-wrapper').clear().type('2');
      //  cy.wait(3000);
 
      //  //Next
      //  cy.get('app-product-quantity.ion-page > .footer-ios > ion-toolbar.ios > .button-round').click({force:true})
      //  cy.wait(1000);
 
      //  //Next
      //  cy.get('app-schedule-product.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      //  cy.wait(1000);
 
      //  //Done
      //  cy.get('app-review-product-details.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      //  cy.wait(1000);
 
 
      //  //Deleting product
      //  cy.get('.can-go-back > .content-ltr > :nth-child(1) > .med-item').click({force:true});
      //  cy.wait(1000);
   
      //  //Delete Product
      //  cy.contains('Delete Product').click();
      //  cy.wait(1000);
   
      //  //Delete
      //  cy.get('.alert-button-role-confirm').click({force:true})
      //  cy.wait(1000);

      //  //Add Supplement
      //  cy.contains('Add Supplement').click({force:true});
      //  cy.wait(2000);
      
      //  cy.scrollTo(0, 2000,{ensureScrollable: false})
      //  //Camera
      //  cy.get('.buttons-last-slot > .ios > .material-symbols-outlined').click({force:true})
      //  cy.wait(30000);
 
      //  //Product Info
      //  cy.get('#ion-input-18').clear().type('Zeo Charge');  
      //  cy.wait(1000);
 
      //  cy.get('#ion-input-19').clear().type('Zeo');
      //  cy.wait(1000);
 
      //  //Next
      //  cy.get('.can-go-back > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      //  cy.wait(1000);
 
      //  //Powder
      //  cy.get(':nth-child(3) > .ng-untouched > :nth-child(2) > .in-item').click({force:true});
      //  cy.wait(2000);
 
      //  //Next
      //  cy.get('[style="z-index: 101;"] > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      //  cy.wait(1000);
    
      //  //Product Quantity
      //  cy.get(':nth-child(2) > .ion-color > .ion-text-end > .input-wrapper > .native-wrapper').clear().type('200');
      //  cy.wait(1000);
 
      //  cy.get(':nth-child(4) > .ion-color > .ion-text-end > .input-wrapper > .native-wrapper').clear().type('2');
      //  cy.wait(3000);
 
      //  //Next
      //  cy.get('app-product-quantity.ion-page > .footer-ios > ion-toolbar.ios > .button-round').click({force:true})
      //  cy.wait(1000);
 
      //  //Next
      //  cy.get('app-schedule-product.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      //  cy.wait(1000);
 
      //  //Done
      //  cy.get('app-review-product-details.ion-page > .footer-ios > ion-toolbar.ios > .ion-color').click({force:true})
      //  cy.wait(1000);
 
      // //Stack -->Back
      // cy.contains('Stack').click({force:true})
      // cy.wait(1000);

      // //Log Extra
      // cy.get(':nth-child(111) > .ion-color-light > .sc-ion-label-ios-h').click({force:true})
      // cy.wait(1000);

      // //Skipped 
      // cy.get('.item-multiple-inputs > :nth-child(1)').click({force:true})
      // cy.wait(1000);

      // //Done
      // cy.get('ion-toolbar.ios > .ion-color').click({force:true})
      // cy.wait(1000);

       //Deleting product
      //  cy.get('.can-go-back > .content-ltr > :nth-child(1) > .med-item').click({force:true});
      //  cy.wait(1000);
   
      //  //Delete Product
      //  cy.contains('Delete Product').click();
      //  cy.wait(1000);
   
      //  //Delete
      //  cy.get('.alert-button-role-confirm').click({force:true})
      //  cy.wait(1000);

    
  })
  })

  // Protocol
// describe('Protocol',()=>{
//   it('About Dashboard & About Timeline',()=>{
//     cy.viewport(1920,1080)
//     cy.visit('https://app.lumati.com/tabs/protocol')
//     cy.wait(3000)
//     // //Protocol
//     cy.get('#tab-button-protocol > .sc-ion-label-ios-h').click({force:true})
//     cy.wait(1000)
//     //Dashboard
//     cy.get('ion-segment.ios > [value="upcoming"]').click({force:true})
//     cy.wait(1000)
//     // //Bio Recharge
//     cy.contains('BioRecharge').click();
//     cy.wait(1000);
//     //Book
//     cy.contains('Book').click();
//     //X button
//     cy.get('.can-go-back > .content-ltr > .fab-horizontal-end > .ion-activatable > .fs-40').click({force:true});

//     //Nutrition Assesment
//     cy.get(':nth-child(1) > .custom-card > .ng-trigger').click({force:true})
//     cy.wait(1000)
//     //Close
//     cy.get('.fs-40').click({force:true})
//     cy.wait(1000)
//     //Welcome to Appointment
//     cy.contains('Welcome to Appointment').click({force:true})
//     cy.wait(1000)
//     //Prep protocol => Button
//     cy.get('.ion-text-center > .ion-no-margin').click({force:true})
//     cy.wait(1000)
//     //Close
//     cy.get('.can-go-back > .content-ltr > .fab-horizontal-end > .ion-activatable > .fs-40').click({force:true})
//     cy.wait(1000)
//     //Timeline
//     cy.get('.segment-button-after-checked').click({force:true})
//     cy.wait(1000)
//     //Bio Recharge
//     cy.contains('BioRecharge').click();
//     cy.wait(1000);
//     //Book
//     cy.contains('Book').click();
//     //X button
//     cy.get('.can-go-back > .content-ltr > .fab-horizontal-end > .ion-activatable > .fs-40').click({force:true});
//   })
// })

 
// Insights
describe('Insights',()=>{
  beforeEach(() => {
    cy.viewport(1920,1080); // Adjust dimensions as needed
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').should('not.exist');

  });
  it('About Insights',()=>{
    // cy.viewport(1920,1080)
    cy.visit('https://app.lumati.com/tabs/biometrics')
    cy.wait(20000)
      
    // //Import
    // cy.get('#import-document').click({force:true}).screenshot({ timeout: 60000 })
    // cy.wait(1000)
    //Photo Library
    // cy.get('.action-sheet-container > :nth-child(1) > :nth-child(3)')
    // cy.wait(10000);
    //Profile
    cy.get(':nth-child(1) > .item-has-start-slot').click({force:true});
    cy.wait(1000)
    //Profile photo
    // cy.get('.round-border-color > img').click({force:true});
    // cy.wait(10000);
    //Title
    cy.get(':nth-child(1) > .ng-untouched').click({force:true});
    cy.wait(1000)
    //Mr 
    cy.get('.action-sheet-selected').click({force:true});
    cy.wait(1000)
    //First name
    cy.get('#ion-input-0').clear().type('Vedhamoorthy');
    cy.wait(1000)
    //Date of birth
    cy.get('#petDatetime > .edit-text').click({force:true});
    cy.wait(1000)
    cy.get('.ion-delegate-host > #petDatetime').click({force:true});
    cy.wait(1000)
    cy.get('.no-padding-top > .buttons-last-slot > .sc-ion-buttons-ios').click({force:true});
    cy.wait(1000)
    //Save 
    cy.get('.can-go-back > .header-ios > .toolbar-title-default > .buttons-last-slot > .sc-ion-buttons-ios').click({force:true});
    cy.wait(1000)
    //Minerals
    cy.get('[routerlink="minerals"] > .ion-activatable').click({force:true})
    cy.wait(1000)
    //Show All
    cy.get('.fs-16').click({force:true});
    cy.wait(1000)
    //Calcium
    cy.get(':nth-child(3) > .list-ios > .ion-activatable').click({force:true});
    cy.wait(1000)

    // Calcium  value
    cy.get(':nth-child(3) > .list-ios > .ion-activatable').click({force:true});
    cy.wait(1000)

    //Back
    cy.get('app-view-marker-test-result.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    cy.wait(1000)

    //Minerals
    cy.get('app-all-biomarker.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    cy.wait(1000)

    //Insights back
    cy.get('.can-go-back > .header-ios > ion-toolbar.ios > .ios').click();
    cy.wait(1000)

    //Vitamins
    cy.get('[routerlink="vitamins"] > .ion-activatable').click({force:true});
    cy.wait(1000)

    //Show all
    cy.get('.fs-16').click();
    cy.wait(1000)

    //Vitamin D3
    cy.get(':nth-child(30) > .list-ios > .ion-activatable > strong').click({force:true});
    cy.wait(1000)

    //Vitamin D3 value
    cy.get('.fw-bold').click({force:true});
    cy.wait(1000)

    cy.get('#tab-button-biometrics').click({force:true});
    cy.wait(1000)

    //Heavy Metals
    cy.get('[routerlink="heavy-metals"] > .ion-activatable').click({force:true});
    cy.wait(1000)

    //Show all
    cy.get('.fs-16').click({force:true});
    cy.wait(1000)

    //Tin
    cy.get(':nth-child(3) > .list-ios > .ion-activatable').click({force:true});
    cy.wait(1000)
    //Tests
    cy.get('app-view-marker-test-result.ion-page > .content-ltr > :nth-child(6) > .list-ios > :nth-child(1)').click({force:true});
    cy.wait(1000)

    //Back
    cy.get('app-view-marker-test-result.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true});
    cy.wait(1000)

    //Thallium
    cy.get(':nth-child(19) > .list-ios > .ion-activatable > strong').click({force:true});
    cy.wait(1000)

    //Back
    cy.get('app-view-marker-test-result.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true});
    cy.wait(1000)

    //Heavy metals Back
    cy.get('app-all-biomarker.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true});
    cy.wait(1000)

    //Insights back
    cy.get('.can-go-back > .header-ios > ion-toolbar.ios > .ios').click({force:true});
    cy.wait(1000)

    //NLS
    cy.get('[routerlink="nls"] > .item-has-start-slot').click({force:true});
    cy.wait(1000)
    
    //Show All
    cy.get(':nth-child(2) > .fs-16').click({force:true})
    cy.wait(1000)

    //Bacteroids Fragilis
    cy.get('app-all-biomarker.ion-page > .content-ltr > :nth-child(53) > .list-ios > .ion-activatable > strong').click({force:true});
    cy.wait(1000)
    //Back
    cy.get('app-view-marker-test-result.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    cy.wait(1000)
    //NLS--> Back
    cy.get('app-all-biomarker.ion-page > .header-ios > .toolbar-title-default > .buttons-first-slot > .sc-ion-buttons-ios').click({force:true})
    cy.wait(1000)
  })
})
 
//Modalities
describe('Modalities',()=>{
  beforeEach(() => {
    cy.viewport(1920,1080); // Adjust dimensions as needed
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').should('not.exist');

  });
  it('About Modaliteis section',()=> {
    // cy.viewport(1920,1080)
      cy.visit('https://app.lumati.com/tabs/booking')
      cy.wait(20000)
      //Modalities
      cy.get('#tab-button-booking').click({force:true})
      cy.wait(1000)

      //Bio Reset
      cy.get(':nth-child(2) > .custom-card > .ion-padding-start > .ion-no-margin').click({force:true})
      cy.wait(1000)
      //Book Appoinment
      cy.get('.ion-no-margin > .ng-star-inserted').click({force:true})
      cy.wait(1000)
      //Book
      cy.get('ion-toolbar.ios > .ion-color').click({force:true})
      cy.wait(1000)

      //Bio Recharge
      cy.get(':nth-child(3) > .custom-card > .ion-padding-start > .ion-no-margin').click({force:true})
      cy.wait(1000)
      //Book
      cy.get('.ion-text-center > .ion-no-margin').click({force:true})
      cy.wait(1000)
      //Close
      cy.get('.can-go-back > .content-ltr > .fab-horizontal-end > .ion-activatable > .fs-40').click({force:true})
      cy.wait(1000)

      //Bio Regen
      cy.get(':nth-child(4) > .custom-card > .ion-padding-start > .ion-no-margin').click({force:true})
      cy.wait(1000)
      //Close
      cy.get('.fs-40').click({force:true})
      cy.wait(1000)

      //Bio Optimization
      cy.get(':nth-child(5) > .custom-card > .ion-padding-start > .ion-no-margin').click({force:true})
      cy.wait(1000)
      //Close
      cy.get('.fs-40').click({force:true})

      //Lumati life subscription
      cy.get(':nth-child(6) > .custom-card > .ion-padding-start > .ion-no-margin').click({force:true})
      cy.wait(1000)
      //Subscribe
      cy.get(':nth-child(7) > .ion-text-center > .ion-no-margin').click({force:true})
      cy.wait(1000)
      //Close
      cy.get('.can-go-back > .content-ltr > .fab-horizontal-end > .ion-activatable > .fs-40').click({force:true})
      cy.wait(1000)

  })
 })

  //Shop
 describe('Shop',()=>{
  beforeEach(() => {
    cy.viewport(1920,1080); // Adjust dimensions as needed
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').should('not.exist');

  });
  it('All Shop contents',()=>{
    // cy.viewport(1920,1080)
    cy.visit('https://app.lumati.com/tabs/store')
    cy.wait(20000)
    //Shop icon
    cy.get('#tab-button-store > .material-symbols-outlined').click({force:true})
    cy.wait(1000)
    //Supplements
    cy.get(':nth-child(1) > .custom-card > .ion-padding-start > .ion-no-margin').click({force:true})
    cy.wait(1000)
    //Buy
    cy.get(':nth-child(3) > ion-row.ios > :nth-child(1) > app-product-card > .ion-color-light > .card-footer > .ml-auto').click({force:true});
    cy.wait(1000)
    //Close
    cy.get('.can-go-back > .content-ltr > .fab-horizontal-end > .ion-activatable > .fs-40').click({force:true});
    cy.wait(1000)

    //Ambrosia
    cy.get(':nth-child(4) > .custom-card > .ion-padding-start > .ion-no-margin').click({force:true});
    cy.wait(1000)

    //Bio Metrics
    cy.get(':nth-child(1) > .info > h5').click({force:true});
    cy.wait(1000)
    //Book
    cy.get(':nth-child(14) > .ion-text-center > .ion-no-margin').click({force:true})
    cy.wait(1000)

    //Close
    cy.get('.can-go-back > .content-ltr > .fab-horizontal-end > .ion-activatable > .fs-40').click({force:true})
    cy.wait(1000)

    //Main -->Close
    cy.get('.fs-40').click({force:true})
    cy.wait(1000)
  })
})

//Logout
describe('Logout',()=>{
  beforeEach(() => {
    cy.viewport(1920,1080); // Adjust dimensions as needed
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(2) > .item-has-start-slot > .sc-ion-label-ios-h').should('not.exist');

  });
  it('About Logout',()=>{
    // cy.viewport(1920,1080)
    // cy.get('#page-to-prevent').should('not.exist');
    cy.visit('https://app.lumati.com/tabs/store')
    //Settings
    cy.wait(10000)
    cy.get('app-user-profile.sc-ion-buttons-ios > .ios > .material-symbols-outlined').click({force:true});
    cy.wait(1000);
    //Logout
    // cy.get(':nth-child(7) > .item-has-start-slot > .sc-ion-label-ios-h').click({force:true})
    cy.get('ion-nav > .ion-page > .content-ltr > :nth-child(7) > .item-has-start-slot > .sc-ion-label-ios-h').click({force:true});
    cy.wait(1000)
})
})